const mammoth = require('mammoth');
const pdfParse = require('pdf-parse');

const MAX_CHARS = 15000;

async function extractText(buffer, mimeType, filename) {
  let text = '';
  try {
    if (mimeType === 'application/pdf' || /\.pdf$/i.test(filename || '')) {
      const data = await pdfParse(buffer);
      text = data.text || '';
    } else if (
      mimeType === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' ||
      /\.docx$/i.test(filename || '')
    ) {
      const result = await mammoth.extractRawText({ buffer });
      text = result.value || '';
    } else {
      text = buffer.toString('utf8');
    }
  } catch (err) {
    text = `[extraction failed: ${err.message}]`;
  }
  if (text.length > MAX_CHARS) {
    text = text.slice(0, MAX_CHARS) + '\n[...truncated...]';
  }
  return text.trim();
}

module.exports = { extractText };
